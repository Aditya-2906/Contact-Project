package com.mycontact;

import java.util.ArrayList;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class ContactDAO {
	
private static final Map<String, Contact> conMap= new HashMap<String, Contact>();
	
	static {initCon();}

	private static void initCon() {
		Contact con1= new Contact("Aditya", "222-767-898");
		Contact con2= new Contact("Prateek", "222-767-747");
		Contact con3= new Contact("Soumojit", "222-767-927");
		
		conMap.put(con1.getContactName(), con1);
		conMap.put(con2.getContactName(), con2);
		conMap.put(con3.getContactName(), con3);
	}
  
	public static Contact getContact(String contactName) {
		return conMap.get(contactName);
	}
	
	public static Contact addContact(Contact con) {
		conMap.put(con.getContactName(), con);
		return con;
	}
	
	public static Contact updateContact(Contact con) {
		conMap.put(con.getContactName(), con);
		return con;
	}
	
	public static void deleteContact(String contactName) {
		conMap.remove(contactName);
	}
	
	public static List<Contact> getAllContacts() {
		Collection<Contact> c = conMap.values();
		List<Contact> list = new ArrayList<Contact>();
		list.addAll(c);
		return list;
	}
	
	List<Contact> list;

}
