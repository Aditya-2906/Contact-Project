export class Contacts{
  contactName: string;
  contactNumber: string;
}