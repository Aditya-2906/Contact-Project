import { Component, OnInit } from '@angular/core';
import { Contacts } from 'src/Contacts';
import { ContactsService } from '../contacts.service';

@Component({
  selector: 'app-add-contact',
  templateUrl: './add-contact.component.html',
  styleUrls: ['./add-contact.component.css']
})
export class AddContactComponent implements OnInit {

  cont: Contacts= new Contacts();
  constructor(private myservice: ContactsService) { 
    this.cont.contactName='';
    this.cont.contactNumber='';
  }

  ngOnInit(): void {
  }

  addContact(){
    this.myservice.addNewContact(this.cont).subscribe(data=>{
     alert(JSON.stringify(data));
     
    })
  }

}
