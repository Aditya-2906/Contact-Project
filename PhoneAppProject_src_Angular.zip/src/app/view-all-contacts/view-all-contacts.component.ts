import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Contacts } from 'src/Contacts';
import { ContactsService } from '../contacts.service';

@Component({
  selector: 'app-view-all-contacts',
  templateUrl: './view-all-contacts.component.html',
  styleUrls: ['./view-all-contacts.component.css']
})
export class ViewAllContactsComponent  {
  
  contName: string ="";

  cont: Contacts= new Contacts();
  contMod: Contacts= new Contacts();

  conts: Contacts[];
  tempConts: Contacts[];

  private subscription: Subscription;

  constructor(private myservice: ContactsService) { }

  ngOnInit() {
    this.subscription = this.myservice.viewAllContacts()
    .subscribe((data:Contacts[]) => {
      this.conts = data;
      this.tempConts = data;
    }, (err) => {
        console.log(err);
    });
  }

  deleteAContact(xyz: string)
  {
    console.log('Name searched'+xyz);
    this.myservice.deleteContact(xyz)
    .subscribe((data: Contacts)=> {

      if(data==null) {
        this.tempConts=this.conts.filter(d=> (d.contactName!=xyz));
        this.conts=this.tempConts;
        console.log('Record Deleted'+xyz);}
      }, (err)=>{
         console.log(err);
      });
 }
       
     updateContactList(){
       if(this.contName==null) {
         console.log('Its Null'+this.contName);
         this.tempConts=this.conts;
       }
       else{
         console.log('Its Not Null '+this.contName);
         this.tempConts=this.conts.filter(d=> (d.contactName==this.contName));
         console.log('tempConts length: '+this.tempConts.length);
         console.log('conts lenght: '+this.conts.length);
       }
     }
    //  addContact(){
    //   this.myservice.addNewContact(this.cont).subscribe(data=>{
    //    alert(JSON.stringify(data));
       
    //   })
    // }

    editContact(){
      this.myservice.modifyContact(this.contMod).subscribe(data =>{
        //alert(JSON.stringify(data));
      })
   }
  
}
