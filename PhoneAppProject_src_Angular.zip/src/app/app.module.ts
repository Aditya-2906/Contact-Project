import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

import {MatIcon,MatIconModule} from '@angular/material/icon';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ViewAllContactsComponent } from './view-all-contacts/view-all-contacts.component';
import { ViewAContactComponent } from './view-acontact/view-acontact.component';
import { AddContactComponent } from './add-contact/add-contact.component';
import { UpdateContactComponent } from './update-contact/update-contact.component';
import { DeleteContactComponent } from './delete-contact/delete-contact.component';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { ContactsService } from './contacts.service';

@NgModule({
  declarations: [
    AppComponent,
    ViewAllContactsComponent,
    ViewAContactComponent,
    AddContactComponent,
    UpdateContactComponent,
    DeleteContactComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    NgbModule,
    MatIconModule
    
    
  ],
  providers: [ContactsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
