import { Component, OnInit } from '@angular/core';
import { Contacts } from 'src/Contacts';
import { ContactsService } from '../contacts.service';

@Component({
  selector: 'app-view-acontact',
  templateUrl: './view-acontact.component.html',
  styleUrls: ['./view-acontact.component.css']
})
export class ViewAContactComponent implements OnInit {

  

  cont: Contacts;
  constructor(private myservice: ContactsService) { }

  ngOnInit(){
    this.myservice.viewAContact(this.cont.contactName)
    .subscribe((data: Contacts) => {
       this.cont=data;
    }, (err) => {
        console.log(err);
  })
}

}
