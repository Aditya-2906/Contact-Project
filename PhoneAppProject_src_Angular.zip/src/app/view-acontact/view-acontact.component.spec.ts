import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAContactComponent } from './view-acontact.component';

describe('ViewAContactComponent', () => {
  let component: ViewAContactComponent;
  let fixture: ComponentFixture<ViewAContactComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewAContactComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAContactComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
