import { Component, OnInit } from '@angular/core';
import { Contacts } from 'src/Contacts';
import { ContactsService } from '../contacts.service';

@Component({
  selector: 'app-update-contact',
  templateUrl: './update-contact.component.html',
  styleUrls: ['./update-contact.component.css']
})
export class UpdateContactComponent implements OnInit {
  
  contMod: Contacts= new Contacts();
  constructor(private myservice: ContactsService) { }

  ngOnInit(): void {
  }
  editContact(){
    this.myservice.modifyContact(this.contMod).subscribe(data =>{
      //alert(JSON.stringify(data));
    })

}
}
