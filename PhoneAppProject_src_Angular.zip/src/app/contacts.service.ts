import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Contacts } from 'src/Contacts';

@Injectable({
  providedIn: 'root'
})
export class ContactsService {

  baseUrl: string = 'http://localhost:8080/FinalContactProject/rest/contacts'

  constructor(private myhttp:HttpClient) { }

  viewAllContacts() : Observable<Contacts[]>
  {
    return this.myhttp.get<Contacts[]>(this.baseUrl+"/getContacts/");
  }

  viewAContact(nameSearch: string): Observable<Contacts>
  {
    return this.myhttp.get<Contacts>(this.baseUrl + "/getContact/" + nameSearch);
  }
  
  addNewContact(newCont:Contacts): Observable<Contacts>
  {
    return this.myhttp.post<Contacts>(this.baseUrl+"/addContact/",newCont);
  }
   
   modifyContact(cont: Contacts): Observable<Contacts>
   {
    return this.myhttp.put<Contacts>(this.baseUrl + "/updateContact/",cont);
   }

   deleteContact(contName: string): Observable<Contacts>
   {
    return this.myhttp.delete<Contacts>(this.baseUrl +"/deleteContact/"+contName);
   }
}
